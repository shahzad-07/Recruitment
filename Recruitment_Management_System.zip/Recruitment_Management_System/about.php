 <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">About Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>

    <section class="page-section">
        <div class="container" style="font-size:20px">
        We student of HKBK College of Engineering are pursuing a degree in engineering, which is a field that involves the design and creation of systems, structures, and machines. We typically have strong analytical and problem-solving skills, and they enjoy using math and science to understand and solve real-world problems. We are typically highly motivated and dedicated, as the field requires a strong work ethic and a willingness to learn. They are also often very creative, as engineering often requires finding innovative solutions to complex challenges. We may choose to specialize in a particular area of engineering, such as mechanical engineering, electrical engineering, or civil engineering. They may also choose to focus on a particular application of engineering. <br> Overall, we are driven and dedicated individuals who are working hard to make a positive impact in the world through the application of their technical skills and knowledge.
        <br><br>
        </div>
        <p style="text-align: right;">
        Mohammed Shahzadul Quadri - 1HK20CS093&emsp;&emsp;&emsp;&emsp;  <br>
        Mohammed Tamheed Shariff  - 1HK20CS095&emsp;&emsp;&emsp;&emsp;  <br>
        Mohammed Yousuf           - 1HK20CS099&emsp;&emsp;&emsp;&emsp;  </p>

        </section>